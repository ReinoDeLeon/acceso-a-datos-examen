//VARIABLES
position = 1
answers = window.sessionStorage //Variable tipo array donde almacenaremos las respuestas del usuario



function cargarTest(test, question, title, p1, p2, p3) {
    /*
    Div, String --> none
    la función recibe el div objetivo donde cargar el html y la cadena que indica que buscamos
    no retorna nada sino que rellena el div con el resultado de la búsqueda
    */

    var ajax1 = new XMLHttpRequest();
    ajax1.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var obj0 = this.responseText;
            var obj1 = JSON.parse(obj0);
            var obj2 = obj1["preguntas"];
            var resultado = "";


            //Controla que no nos pasemos de posiciones
            if (question == 0) {
                position = 1
            }
            if (question > obj2.length) {
                position = obj2.length
            }
            for (let i = 0; i < obj2.length; i++) {
                /*
                Para todos los objetos que encontremos en json generaremos un valor en resultado
                con el código html para inyectarlo en la página después y ahorrar los tiempos de carga
                */
                if (question === obj2[i].id) {
                    //Incorporamos a nuestro HTML los resultados del json
                    document.getElementById("title").innerHTML = obj2[i].titulo
                    document.getElementById("lp1").innerHTML = obj2[i].respuesta[0]
                    document.getElementById("lp2").innerHTML = obj2[i].respuesta[1]
                    document.getElementById("lp3").innerHTML = obj2[i].respuesta[2]
                    document.getElementById("pregunta").innerHTML = "Pregunta " + (i + 1) + " de " + obj2.length
                    document.test.reset()
                }

            }


        }
    };
    ajax1.open("GET", "json/test.json");
    ajax1.send();
}

window.addEventListener("load", function(event) {
    /*
    Null --> Null
    */
    nota = 0
    const testView = document.getElementById("test")
    cargarTest(testView, position, title, p1, p2, p3)
    this.document.getElementById("back").addEventListener("click", function(event) {
        position--
        cargarTest(testView, position)
    })
    this.document.getElementById("forward").addEventListener("click", function(event) {
        position++
        cargarTest(testView, position)
    })
    var rad = document.test.preg;
    for (var i = 0; i < rad.length; i++) {
        rad[i].addEventListener('change', function() {
            answers.setItem((position), this.value)
            console.log(answers.getItem(position) + " at position " + position)
        });
    }
    this.document.getElementById("end").addEventListener("click", function(event) {
        checkAnswers()
        document.getElementById("end").innerHTML = "Reiniciar"
        document.getElementById("end").addEventListener("click", function(event) {
            answers.clear()
            window.location.reload()

        })
    })
})

function checkAnswers() {
    var ajax1 = new XMLHttpRequest();
    ajax1.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var obj0 = this.responseText;
            var obj1 = JSON.parse(obj0);
            var obj2 = obj1["preguntas"];

            for (let index = 0; index < obj2.length; index++) {
                console.log(obj2[index].respuesta[answers.getItem((index + 1)) - 1])
                if (obj2[index].respuesta[answers.getItem((index + 1)) - 1] == obj2[index].solucion) {
                    nota++

                }

            }
            document.getElementById("nota").innerHTML = ("La nota es de " + nota + "/" + obj2.length)
            document.getElementById("test").setAttribute("style", "display: none")



        }
    };
    ajax1.open("GET", "json/test.json");
    ajax1.send();
}